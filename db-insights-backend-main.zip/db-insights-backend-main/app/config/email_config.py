# app/config/email_config.py

RECIPIENTS = [
    "team_member1@example.com",
    "team_member2@example.com",
    "group_email@example.com"
]