from app.config.config import get_settings

settings = get_settings()